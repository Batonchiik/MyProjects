﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculatorBMI_Batov22is_
{
    public partial class Form1 : Form
    {
        float index;
        float v;
        float r; 
        public Form1()
        {
            InitializeComponent();
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {

        }

        private void Back_Click(object sender, EventArgs e)
        {

        }

        private void Count_Click(object sender, EventArgs e)
        {
            r = float.Parse(heiht.Text);
            v = float.Parse(weight.Text);
            r = r / 100;
            index = v / (r * r);
            Result.Text = index.ToString();
            trackBar1.Value = (int)index;

        }

        private void cancel_Click(object sender, EventArgs e)
        {

        }
    }
}
