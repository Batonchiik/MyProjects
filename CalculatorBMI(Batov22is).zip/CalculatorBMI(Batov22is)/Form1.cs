﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculatorBMI_Batov22is_
{
    public partial class Form1 : Form
    {
        float index;
        float v;
        float r; 
        public Form1()
        {
            InitializeComponent();
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {

        }

        private void Back_Click(object sender, EventArgs e)
        {
            App
        }

        private void Count_Click(object sender, EventArgs e)
        {
            r = float.Parse(heiht.Text);
            v = float.Parse(weight.Text);
            r = r / 100;
            index = v / (r * r);
            Result.Text = index.ToString();
            if (index < 18.5)
            {
                index = 5;
                textBox1.Text = "Недостаток";
            }
            else if (index >= 18.5 && index <= 24.9)
            {
                index = 15;
                textBox1.Text = "Здоровый";
            }
            else if (index >= 25 && index <= 29.9)
            {
                index = 25;
                textBox1.Text = "Избыточный";
            }
            else { index = 35; }
            textBox1.Text = "Ожирение";
            
            trackBar1.Value = Convert.ToInt32(index);

        }

       

        private void cancel_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = Properties.Resources.male_icon;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = Properties.Resources.female_icon;
        }
    }
}
