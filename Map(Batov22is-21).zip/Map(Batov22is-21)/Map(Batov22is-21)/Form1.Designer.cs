﻿namespace Map_Batov22is_21_
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.Back = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.labelEnergy = new System.Windows.Forms.Label();
            this.labelInformation = new System.Windows.Forms.Label();
            this.labelMedical = new System.Windows.Forms.Label();
            this.labelToilets = new System.Windows.Forms.Label();
            this.labelDrinks = new System.Windows.Forms.Label();
            this.nameLabel = new System.Windows.Forms.Label();
            this.marafonLabel = new System.Windows.Forms.Label();
            this.pictureBoxDrinks = new System.Windows.Forms.PictureBox();
            this.pictureBoxTuilets = new System.Windows.Forms.PictureBox();
            this.pictureBoxMedical = new System.Windows.Forms.PictureBox();
            this.pictureBoxInformation = new System.Windows.Forms.PictureBox();
            this.pictureBoxEnergy = new System.Windows.Forms.PictureBox();
            this.Finish = new System.Windows.Forms.Button();
            this.button_1 = new System.Windows.Forms.Button();
            this.button_2 = new System.Windows.Forms.Button();
            this.button_3 = new System.Windows.Forms.Button();
            this.button_4 = new System.Windows.Forms.Button();
            this.button_5 = new System.Windows.Forms.Button();
            this.button_6 = new System.Windows.Forms.Button();
            this.button_7 = new System.Windows.Forms.Button();
            this.button_8 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBoxStart_2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxStart_3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxStart_1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDrinks)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTuilets)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMedical)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxInformation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxEnergy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStart_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStart_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStart_1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.Back);
            this.panel1.Location = new System.Drawing.Point(-5, 4);
            this.panel1.Margin = new System.Windows.Forms.Padding(7, 7, 7, 7);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1610, 96);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Palatino Linotype", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(243, 7);
            this.label1.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1132, 87);
            this.label1.TabIndex = 1;
            this.label1.Text = "Interactive map for Marathon Skiills";
            // 
            // Back
            // 
            this.Back.Location = new System.Drawing.Point(7, 18);
            this.Back.Margin = new System.Windows.Forms.Padding(7, 7, 7, 7);
            this.Back.Name = "Back";
            this.Back.Size = new System.Drawing.Size(187, 67);
            this.Back.TabIndex = 0;
            this.Back.Text = "Back";
            this.Back.UseVisualStyleBackColor = true;
            // 
            // labelEnergy
            // 
            this.labelEnergy.AutoSize = true;
            this.labelEnergy.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelEnergy.Location = new System.Drawing.Point(1822, 165);
            this.labelEnergy.Name = "labelEnergy";
            this.labelEnergy.Size = new System.Drawing.Size(249, 48);
            this.labelEnergy.TabIndex = 23;
            this.labelEnergy.Text = "Energy Bars";
            // 
            // labelInformation
            // 
            this.labelInformation.AutoSize = true;
            this.labelInformation.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelInformation.Location = new System.Drawing.Point(1822, 335);
            this.labelInformation.Name = "labelInformation";
            this.labelInformation.Size = new System.Drawing.Size(230, 48);
            this.labelInformation.TabIndex = 24;
            this.labelInformation.Text = "Information";
            // 
            // labelMedical
            // 
            this.labelMedical.AutoSize = true;
            this.labelMedical.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelMedical.Location = new System.Drawing.Point(1822, 514);
            this.labelMedical.Name = "labelMedical";
            this.labelMedical.Size = new System.Drawing.Size(188, 48);
            this.labelMedical.TabIndex = 25;
            this.labelMedical.Text = "Medicine";
            // 
            // labelToilets
            // 
            this.labelToilets.AutoSize = true;
            this.labelToilets.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelToilets.Location = new System.Drawing.Point(1822, 689);
            this.labelToilets.Name = "labelToilets";
            this.labelToilets.Size = new System.Drawing.Size(145, 48);
            this.labelToilets.TabIndex = 26;
            this.labelToilets.Text = "Toilets";
            // 
            // labelDrinks
            // 
            this.labelDrinks.AutoSize = true;
            this.labelDrinks.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelDrinks.Location = new System.Drawing.Point(1828, 856);
            this.labelDrinks.Name = "labelDrinks";
            this.labelDrinks.Size = new System.Drawing.Size(139, 48);
            this.labelDrinks.TabIndex = 27;
            this.labelDrinks.Text = "Drinks";
            // 
            // nameLabel
            // 
            this.nameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.nameLabel.Location = new System.Drawing.Point(1799, 22);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(272, 66);
            this.nameLabel.TabIndex = 28;
            // 
            // marafonLabel
            // 
            this.marafonLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.marafonLabel.Location = new System.Drawing.Point(1893, 89);
            this.marafonLabel.Name = "marafonLabel";
            this.marafonLabel.Size = new System.Drawing.Size(210, 49);
            this.marafonLabel.TabIndex = 29;
            // 
            // pictureBoxDrinks
            // 
            this.pictureBoxDrinks.Image = global::Map_Batov22is_21_.Properties.Resources.map_icon_drinks;
            this.pictureBoxDrinks.Location = new System.Drawing.Point(1629, 811);
            this.pictureBoxDrinks.Margin = new System.Windows.Forms.Padding(7);
            this.pictureBoxDrinks.Name = "pictureBoxDrinks";
            this.pictureBoxDrinks.Size = new System.Drawing.Size(152, 132);
            this.pictureBoxDrinks.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxDrinks.TabIndex = 22;
            this.pictureBoxDrinks.TabStop = false;
            // 
            // pictureBoxTuilets
            // 
            this.pictureBoxTuilets.Image = global::Map_Batov22is_21_.Properties.Resources.map_icon_toilets;
            this.pictureBoxTuilets.Location = new System.Drawing.Point(1629, 642);
            this.pictureBoxTuilets.Margin = new System.Windows.Forms.Padding(7);
            this.pictureBoxTuilets.Name = "pictureBoxTuilets";
            this.pictureBoxTuilets.Size = new System.Drawing.Size(152, 132);
            this.pictureBoxTuilets.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxTuilets.TabIndex = 21;
            this.pictureBoxTuilets.TabStop = false;
            // 
            // pictureBoxMedical
            // 
            this.pictureBoxMedical.Image = global::Map_Batov22is_21_.Properties.Resources.map_icon_medical;
            this.pictureBoxMedical.Location = new System.Drawing.Point(1629, 463);
            this.pictureBoxMedical.Margin = new System.Windows.Forms.Padding(7);
            this.pictureBoxMedical.Name = "pictureBoxMedical";
            this.pictureBoxMedical.Size = new System.Drawing.Size(152, 132);
            this.pictureBoxMedical.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxMedical.TabIndex = 20;
            this.pictureBoxMedical.TabStop = false;
            // 
            // pictureBoxInformation
            // 
            this.pictureBoxInformation.Image = global::Map_Batov22is_21_.Properties.Resources.map_icon_information;
            this.pictureBoxInformation.Location = new System.Drawing.Point(1629, 290);
            this.pictureBoxInformation.Margin = new System.Windows.Forms.Padding(7);
            this.pictureBoxInformation.Name = "pictureBoxInformation";
            this.pictureBoxInformation.Size = new System.Drawing.Size(152, 132);
            this.pictureBoxInformation.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxInformation.TabIndex = 19;
            this.pictureBoxInformation.TabStop = false;
            // 
            // pictureBoxEnergy
            // 
            this.pictureBoxEnergy.Image = global::Map_Batov22is_21_.Properties.Resources.map_icon_energy_bars;
            this.pictureBoxEnergy.Location = new System.Drawing.Point(1629, 129);
            this.pictureBoxEnergy.Margin = new System.Windows.Forms.Padding(7);
            this.pictureBoxEnergy.Name = "pictureBoxEnergy";
            this.pictureBoxEnergy.Size = new System.Drawing.Size(152, 132);
            this.pictureBoxEnergy.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxEnergy.TabIndex = 18;
            this.pictureBoxEnergy.TabStop = false;
            // 
            // Finish
            // 
            this.Finish.BackColor = System.Drawing.SystemColors.HighlightText;
            this.Finish.Image = global::Map_Batov22is_21_.Properties.Resources.finish;
            this.Finish.Location = new System.Drawing.Point(462, 103);
            this.Finish.Margin = new System.Windows.Forms.Padding(7);
            this.Finish.Name = "Finish";
            this.Finish.Size = new System.Drawing.Size(84, 216);
            this.Finish.TabIndex = 11;
            this.Finish.UseVisualStyleBackColor = false;
            this.Finish.Click += new System.EventHandler(this.Finish_Click);
            // 
            // button_1
            // 
            this.button_1.BackColor = System.Drawing.SystemColors.HighlightText;
            this.button_1.Image = global::Map_Batov22is_21_.Properties.Resources._1;
            this.button_1.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button_1.Location = new System.Drawing.Point(751, 114);
            this.button_1.Margin = new System.Windows.Forms.Padding(7);
            this.button_1.Name = "button_1";
            this.button_1.Size = new System.Drawing.Size(154, 136);
            this.button_1.TabIndex = 10;
            this.button_1.UseVisualStyleBackColor = false;
            this.button_1.Click += new System.EventHandler(this.button_1_Click);
            // 
            // button_2
            // 
            this.button_2.BackColor = System.Drawing.SystemColors.HighlightText;
            this.button_2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button_2.Image = global::Map_Batov22is_21_.Properties.Resources._2;
            this.button_2.Location = new System.Drawing.Point(1050, 335);
            this.button_2.Margin = new System.Windows.Forms.Padding(7);
            this.button_2.Name = "button_2";
            this.button_2.Size = new System.Drawing.Size(145, 136);
            this.button_2.TabIndex = 9;
            this.button_2.UseVisualStyleBackColor = false;
            this.button_2.Click += new System.EventHandler(this.button_2_Click);
            // 
            // button_3
            // 
            this.button_3.BackColor = System.Drawing.SystemColors.HighlightText;
            this.button_3.Image = global::Map_Batov22is_21_.Properties.Resources._3;
            this.button_3.Location = new System.Drawing.Point(1050, 560);
            this.button_3.Margin = new System.Windows.Forms.Padding(7);
            this.button_3.Name = "button_3";
            this.button_3.Size = new System.Drawing.Size(142, 149);
            this.button_3.TabIndex = 8;
            this.button_3.UseVisualStyleBackColor = false;
            this.button_3.Click += new System.EventHandler(this.button_3_Click);
            // 
            // button_4
            // 
            this.button_4.BackColor = System.Drawing.SystemColors.HighlightText;
            this.button_4.Image = global::Map_Batov22is_21_.Properties.Resources._4;
            this.button_4.Location = new System.Drawing.Point(1444, 723);
            this.button_4.Margin = new System.Windows.Forms.Padding(7);
            this.button_4.Name = "button_4";
            this.button_4.Size = new System.Drawing.Size(161, 143);
            this.button_4.TabIndex = 7;
            this.button_4.UseVisualStyleBackColor = false;
            this.button_4.Click += new System.EventHandler(this.button_4_Click);
            // 
            // button_5
            // 
            this.button_5.BackColor = System.Drawing.SystemColors.HighlightText;
            this.button_5.Image = global::Map_Batov22is_21_.Properties.Resources._5;
            this.button_5.Location = new System.Drawing.Point(859, 868);
            this.button_5.Margin = new System.Windows.Forms.Padding(7);
            this.button_5.Name = "button_5";
            this.button_5.Size = new System.Drawing.Size(142, 134);
            this.button_5.TabIndex = 6;
            this.button_5.UseVisualStyleBackColor = false;
            this.button_5.Click += new System.EventHandler(this.button_5_Click);
            // 
            // button_6
            // 
            this.button_6.BackColor = System.Drawing.SystemColors.HighlightText;
            this.button_6.Image = global::Map_Batov22is_21_.Properties.Resources._6;
            this.button_6.Location = new System.Drawing.Point(415, 839);
            this.button_6.Margin = new System.Windows.Forms.Padding(7);
            this.button_6.Name = "button_6";
            this.button_6.Size = new System.Drawing.Size(166, 138);
            this.button_6.TabIndex = 5;
            this.button_6.UseVisualStyleBackColor = false;
            this.button_6.Click += new System.EventHandler(this.button_6_Click);
            // 
            // button_7
            // 
            this.button_7.BackColor = System.Drawing.SystemColors.HighlightText;
            this.button_7.Image = global::Map_Batov22is_21_.Properties.Resources._7;
            this.button_7.Location = new System.Drawing.Point(177, 636);
            this.button_7.Margin = new System.Windows.Forms.Padding(7);
            this.button_7.Name = "button_7";
            this.button_7.Size = new System.Drawing.Size(166, 138);
            this.button_7.TabIndex = 4;
            this.button_7.UseVisualStyleBackColor = false;
            this.button_7.Click += new System.EventHandler(this.button_7_Click);
            // 
            // button_8
            // 
            this.button_8.BackColor = System.Drawing.SystemColors.HighlightText;
            this.button_8.Image = global::Map_Batov22is_21_.Properties.Resources._8;
            this.button_8.Location = new System.Drawing.Point(91, 344);
            this.button_8.Margin = new System.Windows.Forms.Padding(7);
            this.button_8.Name = "button_8";
            this.button_8.Size = new System.Drawing.Size(159, 127);
            this.button_8.TabIndex = 3;
            this.button_8.UseVisualStyleBackColor = false;
            this.button_8.Click += new System.EventHandler(this.button_8_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Map_Batov22is_21_.Properties.Resources.map;
            this.pictureBox1.Location = new System.Drawing.Point(-16, 103);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(7);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1621, 899);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBoxStart_2
            // 
            this.pictureBoxStart_2.Image = global::Map_Batov22is_21_.Properties.Resources.map_icon_start;
            this.pictureBoxStart_2.Location = new System.Drawing.Point(100, 481);
            this.pictureBoxStart_2.Name = "pictureBoxStart_2";
            this.pictureBoxStart_2.Size = new System.Drawing.Size(150, 132);
            this.pictureBoxStart_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxStart_2.TabIndex = 31;
            this.pictureBoxStart_2.TabStop = false;
            this.pictureBoxStart_2.Click += new System.EventHandler(this.pictureBoxStart_2_Click);
            // 
            // pictureBoxStart_3
            // 
            this.pictureBoxStart_3.Image = global::Map_Batov22is_21_.Properties.Resources.map_icon_start;
            this.pictureBoxStart_3.Location = new System.Drawing.Point(647, 868);
            this.pictureBoxStart_3.Name = "pictureBoxStart_3";
            this.pictureBoxStart_3.Size = new System.Drawing.Size(150, 132);
            this.pictureBoxStart_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxStart_3.TabIndex = 32;
            this.pictureBoxStart_3.TabStop = false;
            this.pictureBoxStart_3.Click += new System.EventHandler(this.pictureBoxStart_3_Click);
            // 
            // pictureBoxStart_1
            // 
            this.pictureBoxStart_1.Image = global::Map_Batov22is_21_.Properties.Resources.map_icon_start;
            this.pictureBoxStart_1.Location = new System.Drawing.Point(556, 118);
            this.pictureBoxStart_1.Name = "pictureBoxStart_1";
            this.pictureBoxStart_1.Size = new System.Drawing.Size(150, 132);
            this.pictureBoxStart_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxStart_1.TabIndex = 33;
            this.pictureBoxStart_1.TabStop = false;
            this.pictureBoxStart_1.Click += new System.EventHandler(this.pictureBoxStart_1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(2183, 1010);
            this.Controls.Add(this.pictureBoxStart_1);
            this.Controls.Add(this.pictureBoxStart_3);
            this.Controls.Add(this.pictureBoxStart_2);
            this.Controls.Add(this.marafonLabel);
            this.Controls.Add(this.nameLabel);
            this.Controls.Add(this.labelDrinks);
            this.Controls.Add(this.labelToilets);
            this.Controls.Add(this.labelMedical);
            this.Controls.Add(this.labelInformation);
            this.Controls.Add(this.labelEnergy);
            this.Controls.Add(this.pictureBoxDrinks);
            this.Controls.Add(this.pictureBoxTuilets);
            this.Controls.Add(this.pictureBoxMedical);
            this.Controls.Add(this.pictureBoxInformation);
            this.Controls.Add(this.pictureBoxEnergy);
            this.Controls.Add(this.Finish);
            this.Controls.Add(this.button_1);
            this.Controls.Add(this.button_2);
            this.Controls.Add(this.button_3);
            this.Controls.Add(this.button_4);
            this.Controls.Add(this.button_5);
            this.Controls.Add(this.button_6);
            this.Controls.Add(this.button_7);
            this.Controls.Add(this.button_8);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(7, 7, 7, 7);
            this.Name = "Form1";
            this.Text = "Marathon";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDrinks)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTuilets)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMedical)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxInformation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxEnergy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStart_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStart_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStart_1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Back;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button_8;
        private System.Windows.Forms.Button button_7;
        private System.Windows.Forms.Button button_6;
        private System.Windows.Forms.Button button_5;
        private System.Windows.Forms.Button button_4;
        private System.Windows.Forms.Button button_3;
        private System.Windows.Forms.Button button_2;
        private System.Windows.Forms.Button button_1;
        private System.Windows.Forms.Button Finish;
        private System.Windows.Forms.PictureBox pictureBoxEnergy;
        private System.Windows.Forms.PictureBox pictureBoxInformation;
        private System.Windows.Forms.PictureBox pictureBoxMedical;
        private System.Windows.Forms.PictureBox pictureBoxTuilets;
        private System.Windows.Forms.PictureBox pictureBoxDrinks;
        private System.Windows.Forms.Label labelEnergy;
        private System.Windows.Forms.Label labelInformation;
        private System.Windows.Forms.Label labelMedical;
        private System.Windows.Forms.Label labelToilets;
        private System.Windows.Forms.Label labelDrinks;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Label marafonLabel;
        private System.Windows.Forms.PictureBox pictureBoxStart_2;
        private System.Windows.Forms.PictureBox pictureBoxStart_3;
        private System.Windows.Forms.PictureBox pictureBoxStart_1;
    }
}

