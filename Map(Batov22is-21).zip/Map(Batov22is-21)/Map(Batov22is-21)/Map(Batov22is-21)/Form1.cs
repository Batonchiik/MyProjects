﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Map_Batov22is_21_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }
        private void clear()
        {
            pictureBoxDrinks.Visible = false; labelDrinks.Visible = false;
            pictureBoxEnergy.Visible = false; labelEnergy.Visible = false;
            pictureBoxTuilets.Visible = false; labelToilets.Visible = false;
            pictureBoxInformation.Visible = false; labelInformation.Visible = false;
            pictureBoxMedical.Visible = false; labelMedical.Visible = false;
        }
        
        private void button_1_Click(object sender, EventArgs e)
        {
            clear();
            nameLabel.Text = "MCC Luzhniki";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            
        }

        private void button_2_Click(object sender, EventArgs e)
        {
            clear();
            nameLabel.Text = "Novodevichy Convent";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxTuilets.Visible = true; labelToilets.Visible = true;
            pictureBoxInformation.Visible = true; labelInformation.Visible = true;
            pictureBoxMedical.Visible = true; labelMedical.Visible = true;
            

        }

        private void button_3_Click(object sender, EventArgs e)
        {
            clear();
            nameLabel.Text = "Metro Kiyevskaya";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxTuilets.Visible = true; labelToilets.Visible = true;

        }

        private void button_4_Click(object sender, EventArgs e)
        {
            clear();
            nameLabel.Text = "MID";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxTuilets.Visible = true; labelToilets.Visible = true;
            pictureBoxMedical.Visible = true; labelMedical.Visible = true;
            pictureBoxMedical.Location = new Point(698,274); labelMedical.Location = new Point(781, 294);
        }

        private void button_5_Click(object sender, EventArgs e)
        {
            clear();
            nameLabel.Text = "Gorky Park";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxTuilets.Visible = true; labelToilets.Visible = true;
            pictureBoxInformation.Visible = true; labelInformation.Visible = true;
        }

        private void button_6_Click(object sender, EventArgs e)
        {
            clear();
            nameLabel.Text = "Building RAN";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxTuilets.Visible = true; labelToilets.Visible = true;
        }

        private void button_7_Click(object sender, EventArgs e)
        {
            clear();
            nameLabel.Text = "Metro Vorobyevyi gory";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxTuilets.Visible = true; labelToilets.Visible = true;
            pictureBoxInformation.Visible = true; labelInformation.Visible = true;
            pictureBoxMedical.Visible = true; labelMedical.Visible = true;
            pictureBoxInformation.Location = new Point(698, 353); labelInformation.Location = new Point(784,364 );
        }

        private void button_8_Click(object sender, EventArgs e)
        {
            clear();
            nameLabel.Text = "Statdium Luzhniki";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxTuilets.Visible = true; labelToilets.Visible = true;
            pictureBoxInformation.Visible = true; labelInformation.Visible = true;
            pictureBoxMedical.Visible = true; labelMedical.Visible = true;
        }

        

        private void pictureBoxStart_1_Click(object sender, EventArgs e)
        {
            clear();
            nameLabel.Text = "Race start 1";
            marafonLabel.Text = "Samba full marafon";
           
        }

        private void pictureBoxStart_2_Click(object sender, EventArgs e)
        {
            clear();
            nameLabel.Text = "Race start 2";
            marafonLabel.Text = "Jongo Half Marafon";
            
        }

        private void pictureBoxStart_3_Click(object sender, EventArgs e)
        {
            clear();
            nameLabel.Text = "Race start 3";
            marafonLabel.Text = "Capoiera Fun Run 5km";
            
        }
        private void Finish_Click(object sender, EventArgs e)
        {
            nameLabel.Text = "Finish!";
        }

        private void Back_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
