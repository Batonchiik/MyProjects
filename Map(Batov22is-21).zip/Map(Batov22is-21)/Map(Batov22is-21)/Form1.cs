﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Map_Batov22is_21_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            clear();
        }
        private void clear()
        {
            pictureBoxDrinks.Visible = false; labelDrinks.Visible = false;
            pictureBoxEnergy.Visible = false; labelEnergy.Visible = false;
            pictureBoxTuilets.Visible = false; labelToilets.Visible = false;
            pictureBoxInformation.Visible = false; labelInformation.Visible = false;
            pictureBoxMedical.Visible = false; labelMedical.Visible = false;
        }
        
        private void button_1_Click(object sender, EventArgs e)
        {
            clear();
            nameLabel.Text = "МЦК Лужники";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
        }

        private void button_2_Click(object sender, EventArgs e)
        {
            clear();
            nameLabel.Text = "Новодевичей монастырь";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxTuilets.Visible = true; labelToilets.Visible = true;
            pictureBoxInformation.Visible = true; labelInformation.Visible = true;
            pictureBoxMedical.Visible = true; labelMedical.Visible = true;

        }

        private void button_3_Click(object sender, EventArgs e)
        {
            clear();
            nameLabel.Text = "Метро Киевская";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxTuilets.Visible = true; labelToilets.Visible = true;

        }

        private void button_4_Click(object sender, EventArgs e)
        {
            clear();
            nameLabel.Text = "МИД";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxTuilets.Visible = true; labelToilets.Visible = true;
            pictureBoxMedical.Visible = true; labelMedical.Visible = true;
            
        }

        private void button_5_Click(object sender, EventArgs e)
        {
            clear();
            nameLabel.Text = "Парк Горького";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxTuilets.Visible = true; labelToilets.Visible = true;
            pictureBoxInformation.Visible = true; labelInformation.Visible = true;
        }

        private void button_6_Click(object sender, EventArgs e)
        {
            clear();
            nameLabel.Text = "Здание РАН";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxTuilets.Visible = true; labelToilets.Visible = true;
        }

        private void button_7_Click(object sender, EventArgs e)
        {
            clear();
            nameLabel.Text = "Метро Воробьевы горы";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxTuilets.Visible = true; labelToilets.Visible = true;
            pictureBoxInformation.Visible = true; labelInformation.Visible = true;
            pictureBoxMedical.Visible = true; labelMedical.Visible = true;
        }

        private void button_8_Click(object sender, EventArgs e)
        {
            clear();
            nameLabel.Text = "Стадион Лужники";
            pictureBoxDrinks.Visible = true; labelDrinks.Visible = true;
            pictureBoxEnergy.Visible = true; labelEnergy.Visible = true;
            pictureBoxTuilets.Visible = true; labelToilets.Visible = true;
            pictureBoxInformation.Visible = true; labelInformation.Visible = true;
            pictureBoxMedical.Visible = true; labelMedical.Visible = true;
        }

        

        private void pictureBoxStart_1_Click(object sender, EventArgs e)
        {
            nameLabel.Text = "Race start 1";
            marafonLabel.Text = "Samba full marafon";
            clear();
        }

        private void pictureBoxStart_2_Click(object sender, EventArgs e)
        {
            nameLabel.Text = "Race start 2";
            marafonLabel.Text = "Jongo Half Marafon";
            clear();
        }

        private void pictureBoxStart_3_Click(object sender, EventArgs e)
        {
            nameLabel.Text = "Race start 3";
            marafonLabel.Text = "Capoiera Fun Run 5km";
            clear();
        }
        private void Finish_Click(object sender, EventArgs e)
        {
            nameLabel.Text = "Finish!";
        }
    }
}
