﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace batov_22is
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonopen_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
                richTextBox.Clear();
                openFileDialog1.Filter = "Text Files (*.txt)|*.txt"; 
            string fileName = openFileDialog1.FileName; 
                richTextBox.Text = File.ReadAllText(fileName, Encoding.GetEncoding(1251)); 
        }

        private void Save_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "Text Files|*.txt";
            saveFileDialog1.DefaultExt = ".txt";
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                var name = saveFileDialog1.FileName;
                File.WriteAllText(name, richTextBox.Text, Encoding.GetEncoding(1251));
            }
            richTextBox.Clear();
        }


        private void richTextBox_TextChanged(object sender, EventArgs e)
        {
            richTextBox.Select(); // выравнивание только выделенного текста
            richTextBox.SelectAll(); //выделение всего текста
            richTextBox.SelectionAlignment = HorizontalAlignment.Center;
            richTextBox.DeselectAll();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (Clipboard.GetDataObject().GetDataPresent(DataFormats.Text) == true)
            {
                // Determine if any text is selected in the text box.
                if (richTextBox.SelectionLength > 0)
                {
                    // Ask user if they want to paste over currently selected text.
                    if (MessageBox.Show("Do you want to paste over current selection?", "Cut Example", MessageBoxButtons.YesNo) == DialogResult.No)
                        // Move selection to the point after the current selection and paste.
                        richTextBox.SelectionStart = richTextBox.SelectionStart + richTextBox.SelectionLength;
                }
                // Paste current text in Clipboard into text box.
                richTextBox.Paste();
            }
        }

        private void копироватьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Ensure that text is selected in the text box.   
            if (richTextBox.SelectionLength > 0)
                // Copy the selected text to the Clipboard.
                richTextBox.Copy();
        }

        private void вырезатьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (richTextBox.SelectedText != "")
                // Cut the selected text in the control and paste it into the Clipboard.
                richTextBox.Cut();
        }

        private void вставитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Clipboard.GetDataObject().GetDataPresent(DataFormats.Text) == true)
            {
                // Determine if any text is selected in the text box.
                if (richTextBox.SelectionLength > 0)
                {
                    // Ask user if they want to paste over currently selected text.
                    if (MessageBox.Show("Do you want to paste over current selection?", "Cut Example", MessageBoxButtons.YesNo) == DialogResult.No)
                        // Move selection to the point after the current selection and paste.
                        richTextBox.SelectionStart = richTextBox.SelectionStart + richTextBox.SelectionLength;
                }
                // Paste current text in Clipboard into text box.
                richTextBox.Paste();
            }
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Font myFont = new Font("Tahoma", 12, FontStyle.Regular, GraphicsUnit.Pixel);
            string Hello = "Hello World!";
            e.Graphics.DrawString(Hello, myFont, Brushes.Black, 20, 20);
        }

        private void печатьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (printDialog1.ShowDialog() == DialogResult.OK) printDocument1.Print();
        }

        private void настройкаПринтераToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            pageSetupDialog1.ShowDialog();
        }

        private void предварительныйПросмторToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            printPreviewDialog1.ShowDialog();
        }

        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
                       
            AboutBox1 form = new AboutBox1();
            form.Show();
            this.Hide();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (richTextBox.SelectedText != "")
                // Cut the selected text in the control and paste it into the Clipboard.
                richTextBox.Cut();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            // Ensure that text is selected in the text box.   
            if (richTextBox.SelectionLength > 0)
                // Copy the selected text to the Clipboard.
                richTextBox.Copy();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            richTextBox.Clear();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            
        }
    }
}
